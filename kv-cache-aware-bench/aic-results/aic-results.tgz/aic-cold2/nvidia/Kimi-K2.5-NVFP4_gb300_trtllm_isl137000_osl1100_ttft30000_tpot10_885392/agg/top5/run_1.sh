#!/bin/bash
set -e
trap 'echo "Cleaning up..."; kill 0 2>/dev/null || true' EXIT INT TERM

export MODEL_PATH=${MODEL_PATH:-"nvidia/Kimi-K2.5-NVFP4"}
export HF_TOKEN=${HF_TOKEN:-"None"}
export SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-"nvidia/Kimi-K2.5-NVFP4"}
export HEAD_NODE_IP=${HEAD_NODE_IP:-"0.0.0.0"}
export ETCD_ENDPOINTS="${HEAD_NODE_IP}:2379"
export NATS_SERVER="nats://${HEAD_NODE_IP}:4222"



AGG_GPU=4
AGG_WORKERS=1
AGG_GPU_OFFSET=0
for ((w=0; w<AGG_WORKERS; w++)); do
  BASE=$(( AGG_GPU_OFFSET + w * AGG_GPU ))
  GPU_LIST=$(seq -s, $BASE $((BASE+AGG_GPU-1)))
  (
    CUDA_VISIBLE_DEVICES=$GPU_LIST python3 -m dynamo.trtllm \
    --model-path "$MODEL_PATH" \
    --served-model-name "$SERVED_MODEL_NAME" \
    --extra-engine-args "/workspace/engine_configs/agg_config.yaml" \
\
 2>&1 | sed "s/^/[Worker $w] /" ) &
done
wait
